export class Produit{
    nom : String = "";
    prix : number = 0;
}