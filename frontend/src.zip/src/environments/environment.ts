export const environment = {production : false,
    backend : "/assets/mock/produits.json"
}
